package org.firstinspires.ftc.teamcode;


import com.qualcomm.robotcore.eventloop.opmode.OpMode;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.DcMotorSimple;

    @TeleOp
    public abstract class BasicTankDrive extends OpMode {

    DcMotor leftmotor;
    DcMotor rightmotor;


    @Override
    public void init() {
        //  int wholeNum - 121;   //stores whole numbers
        //  double pi =  3.1415926;  //holds decimals and whole numbers
        //  boolean doihavefriends  = false; //true or false
        String innitMessage = "initialized";
            telemetry.addData("Status", innitMessage); //Status inialized (sending stuff to gamepad)

            leftmotor = hardwareMap.get(DcMotor.class, "leftmotor");
            rightmotor = hardwareMap.get(DcMotor.class, "rightmotor");

            leftmotor.setMode(DcMotor.RunMode.RUN_WITHOUT_ENCODER);
            rightmotor.setMode(DcMotor.RunMode.RUN_WITHOUT_ENCODER);

            leftmotor.setDirection(DcMotorSimple.Direction.REVERSE);

    }

    @Override
    public void loop() {
        double leftPower = -gamepad1.left_stick_y;
        double rightPower = -gamepad1.right_stick_y;

        double avgPower = (leftPower + rightPower) / 2;
        boolean isfast = avgPower > 0.75;
        if (isfast) {
            telemetry.addData("Speed of Robot", avgPower);
        }
            else {
                telemetry.addData("Robot is fast?",  false);
            }
        leftmotor.setPower(leftPower);
        rightmotor.setPower(rightPower);


    if (avgPower > 0.75) {

        leftmotor.setPower(1);
        leftmotor.setPower(1);

    }

    if (leftPower > 0.5 && rightPower < 0.5) {

        leftmotor.setPower(-1);
        leftmotor.setPower(1);

    }

    if (rightPower > 0.5 && leftPower < 0.5) {

        leftmotor.setPower(1);
        leftmotor.setPower(-1);

    }

    if (avgPower < 0.75) {

        leftmotor.setPower(-1);
        leftmotor.setPower(-1);

    }

    }
}
